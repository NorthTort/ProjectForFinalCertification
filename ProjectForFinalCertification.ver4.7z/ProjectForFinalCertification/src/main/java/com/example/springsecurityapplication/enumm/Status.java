package com.example.springsecurityapplication.enumm;

public enum Status {
    Принят, Оформлен, Собирается, Собран, Выдан, Отменен
}
